#!/usr/bin/env python3
"""
Human-approved CloudFormation assignment agent.
Uses the local AWS CLI identity; never stores AWS credentials.
All AWS operations are restricted to the configured region.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import shlex
import shutil
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = ROOT / "config" / "agent_config.json"
LOG_DIR = ROOT / "logs"
EVIDENCE_DIR = ROOT / "evidence"


def load_config():
    if not CONFIG_PATH.exists():
        raise SystemExit(f"Missing {CONFIG_PATH}. Copy config/agent_config.example.json to config/agent_config.json.")
    cfg = json.loads(CONFIG_PATH.read_text())
    cfg.setdefault("region", "us-east-1")
    cfg.setdefault("expected_account_id", "")
    cfg.setdefault("require_approval", True)
    cfg.setdefault("allowed_regions", ["us-east-1"])
    return cfg


CFG = None


def log_event(event, data):
    LOG_DIR.mkdir(exist_ok=True)
    record = {
        "timestamp": dt.datetime.now(dt.timezone.utc).isoformat(),
        "event": event,
        "data": data,
    }
    with (LOG_DIR / "agent.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, default=str) + "\n")


def run(args, check=True, capture=True):
    cmd = ["aws", *args, "--region", CFG["region"]]
    print("$ " + shlex.join(cmd))
    p = subprocess.run(cmd, text=True, capture_output=capture)
    stdout = p.stdout if capture else ""
    stderr = p.stderr if capture else ""
    if stdout:
        print(stdout.rstrip())
    if p.returncode != 0:
        if stderr:
            print(stderr.rstrip(), file=sys.stderr)
        log_event("aws_command_failed", {"command": cmd, "returncode": p.returncode, "stderr": stderr})
        if check:
            raise SystemExit(p.returncode)
    else:
        log_event("aws_command", {"command": cmd, "returncode": 0})
    return stdout


def aws_json(args, check=True):
    out = run(args + ["--output", "json"], check=check)
    if not out.strip():
        return {}
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        raise SystemExit("AWS CLI returned output that was not valid JSON.")


def ensure_environment():
    if shutil.which("aws") is None:
        raise SystemExit("AWS CLI was not found. Open AWS CloudShell or install AWS CLI v2.")
    region = CFG["region"]
    if region not in CFG["allowed_regions"]:
        raise SystemExit(f"Blocked region {region}; allowed regions: {CFG['allowed_regions']}")
    identity = aws_json(["sts", "get-caller-identity"])
    account = identity.get("Account", "")
    expected = CFG.get("expected_account_id", "").strip()
    print(f"\nAuthenticated AWS account: {account}")
    print(f"Execution region: {region}")
    if expected and account != expected:
        raise SystemExit(f"Account mismatch. Expected {expected}, authenticated as {account}.")
    log_event("identity_verified", {"account": account, "arn": identity.get("Arn"), "region": region})
    return identity


def template_path(value):
    p = Path(value)
    if not p.is_absolute():
        p = ROOT / p
    p = p.resolve()
    if not p.is_file():
        raise SystemExit(f"Template not found: {p}")
    if p.stat().st_size > 51200:
        raise SystemExit("Template exceeds the 51,200-byte TemplateBody limit. Upload it to S3 and extend the agent before deployment.")
    return p


def validate_template(args):
    p = template_path(args.template)
    print(f"\nValidating {p.name} with AWS CloudFormation...")
    result = aws_json(["cloudformation", "validate-template", "--template-body", f"file://{p}"])
    print("\nCloudFormation validation passed.")
    if result.get("Description"):
        print("Description:", result["Description"])
    if result.get("Parameters"):
        print("Parameters:")
        for item in result["Parameters"]:
            print(" -", item.get("ParameterKey"), item.get("DefaultValue", "(no default)"))
    log_event("template_validated", {"path": str(p), "parameters": result.get("Parameters", [])})


def inspect(args):
    print("\n=== AWS identity ===")
    identity = ensure_environment()
    print("\n=== CloudFormation stacks ===")
    stacks = aws_json(["cloudformation", "list-stacks", "--stack-status-filter",
                       "CREATE_IN_PROGRESS", "CREATE_COMPLETE", "UPDATE_IN_PROGRESS",
                       "UPDATE_COMPLETE", "UPDATE_ROLLBACK_COMPLETE", "ROLLBACK_COMPLETE"])
    for s in stacks.get("StackSummaries", []):
        print(f" - {s['StackName']}: {s['StackStatus']}")
    print("\n=== CloudFormation exports ===")
    exports = aws_json(["cloudformation", "list-exports"])
    for e in exports.get("Exports", []):
        print(f" - {e.get('Name')} = {e.get('Value')}")
    print("\n=== Region ===")
    print(CFG["region"])
    log_event("inspection_complete", {"account": identity.get("Account"),
                                      "stack_count": len(stacks.get("StackSummaries", [])),
                                      "export_count": len(exports.get("Exports", []))})


def parse_parameters(items):
    params = []
    for item in items or []:
        if "=" not in item:
            raise SystemExit(f"Invalid parameter '{item}'. Use ParameterKey=ParameterValue.")
        k, v = item.split("=", 1)
        params.append({"ParameterKey": k, "ParameterValue": v})
    return params


def plan(args):
    p = template_path(args.template)
    ensure_environment()
    # Always validate before creating a change set.
    aws_json(["cloudformation", "validate-template", "--template-body", f"file://{p}"])
    stack = args.stack
    desc = args.description or f"Agent plan {dt.datetime.now().strftime('%Y%m%d-%H%M%S')}"
    exists = aws_json(["cloudformation", "describe-stacks", "--stack-name", stack], check=False)
    stack_exists = bool(exists.get("Stacks"))
    change_type = "UPDATE" if stack_exists else "CREATE"
    cs_name = args.change_set_name or f"agent-{stack}-{dt.datetime.now().strftime('%Y%m%d%H%M%S')}"
    command = [
        "cloudformation", "create-change-set",
        "--stack-name", stack,
        "--change-set-name", cs_name,
        "--change-set-type", change_type,
        "--template-body", f"file://{p}",
        "--description", desc,
        "--parameters",
    ]
    parameters = parse_parameters(args.parameter)
    command.append(json.dumps(parameters) if parameters else "[]")
    if args.capability:
        command += ["--capabilities", *args.capability]
    if args.tags:
        tags = []
        for item in args.tags:
            if "=" not in item:
                raise SystemExit(f"Invalid tag '{item}'. Use Key=Value.")
            k, v = item.split("=", 1)
            tags.append({"Key": k, "Value": v})
        command += ["--tags", json.dumps(tags)]
    response = aws_json(command)
    change_set_id = response["Id"]
    print(f"\nChange set created: {change_set_id}")
    print("Waiting for CloudFormation to finish preparing the change set...")
    wait = run(["cloudformation", "wait", "change-set-create-complete", "--change-set-name", change_set_id], check=False)
    details = aws_json(["cloudformation", "describe-change-set", "--change-set-name", change_set_id], check=False)
    status = details.get("Status")
    reason = details.get("StatusReason", "")
    print(f"\nChange set status: {status}")
    if reason:
        print("Reason:", reason)
    changes = details.get("Changes", [])
    if not changes:
        print("No resource changes were returned. Review the status/reason above.")
    else:
        print("\nPROPOSED RESOURCE CHANGES")
        for c in changes:
            r = c.get("ResourceChange", {})
            print(f" - {r.get('Action')} {r.get('LogicalResourceId')} "
                  f"({r.get('ResourceType')}); replacement={r.get('Replacement')}")
    EVIDENCE_DIR.mkdir(exist_ok=True)
    evidence = EVIDENCE_DIR / f"change-set-{cs_name}.json"
    evidence.write_text(json.dumps(details, indent=2))
    log_event("change_set_planned", {"stack": stack, "change_set": change_set_id,
                                     "status": status, "changes": changes})
    print(f"\nFull change-set details saved to {evidence}")
    print("\nNothing has been deployed. To execute, run the execute command with this exact change-set name.")


def execute(args):
    ensure_environment()
    stack = args.stack
    cs = args.change_set
    details = aws_json(["cloudformation", "describe-change-set", "--stack-name", stack,
                        "--change-set-name", cs])
    status = details.get("Status")
    if status != "CREATE_COMPLETE":
        raise SystemExit(f"Refusing execution: change set status is {status}, not CREATE_COMPLETE.")
    changes = details.get("Changes", [])
    if not changes:
        raise SystemExit("Refusing execution: change set contains no resource changes.")
    print("\nYou are about to execute this CloudFormation change set:")
    print(f"Stack: {stack}\nChange set: {cs}\nRegion: {CFG['region']}")
    for c in changes:
        r = c.get("ResourceChange", {})
        print(f" - {r.get('Action')} {r.get('LogicalResourceId')} ({r.get('ResourceType')})")
    required = f"EXECUTE {stack} {cs}"
    typed = input(f"\nType exactly '{required}' to proceed: ").strip()
    if typed != required:
        raise SystemExit("Approval did not match. No deployment was executed.")
    run(["cloudformation", "execute-change-set", "--stack-name", stack, "--change-set-name", cs])
    log_event("change_set_execution_started", {"stack": stack, "change_set": cs})
    print("\nWaiting for stack operation to finish...")
    # Determine waiter from whether the stack existed before execution.
    stack_before = aws_json(
        ["cloudformation", "describe-stacks", "--stack-name", stack],
        check=False
    )
    waiter = "stack-update-complete" if stack_before.get("Stacks") else "stack-create-complete"
    print(f"Using CloudFormation waiter: {waiter}")
    run(["cloudformation", "wait", waiter, "--stack-name", stack], check=False)
    final = aws_json(["cloudformation", "describe-stacks", "--stack-name", stack], check=False)
    if not final.get("Stacks"):
        raise SystemExit("Stack was not found after execution; inspect CloudFormation events.")
    s = final["Stacks"][0]
    print("\nFinal stack status:", s.get("StackStatus"))
    print("Stack outputs:")
    for o in s.get("Outputs", []):
        print(f" - {o.get('OutputKey')}: {o.get('OutputValue')}")
    log_event("stack_operation_finished", {"stack": stack, "status": s.get("StackStatus"),
                                           "outputs": s.get("Outputs", [])})


def status(args):
    ensure_environment()
    stacks = aws_json(["cloudformation", "describe-stacks", "--stack-name", args.stack], check=False)
    if not stacks.get("Stacks"):
        print(f"Stack {args.stack} not found.")
        return
    s = stacks["Stacks"][0]
    print(f"{s['StackName']}: {s['StackStatus']}")
    for o in s.get("Outputs", []):
        print(f" - {o.get('OutputKey')}: {o.get('OutputValue')}")
    resources = aws_json(["cloudformation", "list-stack-resources", "--stack-name", args.stack])
    print("\nResources:")
    for r in resources.get("StackResourceSummaries", []):
        print(f" - {r.get('LogicalResourceId')}: {r.get('ResourceType')} "
              f"{r.get('ResourceStatus')} {r.get('PhysicalResourceId', '')}")


def cleanup_plan(args):
    ensure_environment()
    stacks = aws_json(["cloudformation", "describe-stacks", "--stack-name", args.stack], check=False)
    if not stacks.get("Stacks"):
        print(f"Stack {args.stack} not found.")
        return
    resources = aws_json(["cloudformation", "list-stack-resources", "--stack-name", args.stack])
    print(f"\nCLEANUP PLAN ONLY — no deletion will occur.\nStack: {args.stack}")
    for r in resources.get("StackResourceSummaries", []):
        print(f" - {r.get('LogicalResourceId')}: {r.get('ResourceType')} "
              f"{r.get('PhysicalResourceId', '')} [{r.get('ResourceStatus')}]")
    print("\nReview DeletionPolicy, UpdateReplacePolicy, retained resources, snapshots, "
          "and resources created outside this stack before approving deletion.")
    print("Deleting a stack does not guarantee deletion of retained resources or external dependencies.")
    log_event("cleanup_plan_created", {"stack": args.stack,
                                       "resources": resources.get("StackResourceSummaries", [])})


def cleanup(args):
    ensure_environment()
    if not args.confirm:
        raise SystemExit("Cleanup is disabled unless you pass --confirm AND type the exact approval phrase.")
    phrase = f"DELETE STACK {args.stack}"
    print(f"WARNING: This requests deletion of CloudFormation stack {args.stack}.")
    typed = input(f"Type exactly '{phrase}' to proceed: ").strip()
    if typed != phrase:
        raise SystemExit("Approval did not match. Nothing was deleted.")
    run(["cloudformation", "delete-stack", "--stack-name", args.stack])
    log_event("stack_deletion_requested", {"stack": args.stack})
    print("Deletion requested. Check stack events and inspect retained resources separately.")



def run_all(args):
    """Orchestrate the two-stack Cafe deployment and collect verification evidence."""
    import argparse

    identity = ensure_environment()
    EVIDENCE_DIR.mkdir(exist_ok=True)

    print("\n" + "=" * 65)
    print("SEIS 615 CAFE ASSIGNMENT — AUTOMATED DEPLOYMENT")
    print("=" * 65)
    print("Account:", identity.get("Account", "unknown"))
    print("Region:", CFG["region"])
    print("Stages: network -> application -> verification -> evidence")

    # The old database instance was found stopped, with no attached EBS volumes.
    old_db = aws_json([
        "ec2", "describe-instances",
        "--instance-ids", "i-0bdc2f53330f6d9a1"
    ], check=False)
    old_instances = [
        i for r in old_db.get("Reservations", [])
        for i in r.get("Instances", [])
    ]
    if old_instances:
        mappings = old_instances[0].get("BlockDeviceMappings", [])
        if not mappings:
            print("\nDATABASE RECOVERY WARNING")
            print("The original stopped DB instance currently reports no attached EBS volumes.")
            print("The new RDS database will not automatically contain the old Café data.")
            approval = input(
                "\nType CONTINUE WITH EMPTY DATABASE to proceed with infrastructure deployment: "
            ).strip()
            if approval != "CONTINUE WITH EMPTY DATABASE":
                raise SystemExit("Stopped before deployment. No new resources were created.")

    # Stage 1: Network
    network_cs = "cafe-network-auto-" + dt.datetime.now().strftime("%Y%m%d%H%M%S")
    network_args = argparse.Namespace(
        stack="cafe-network",
        template="templates/lab-network.yaml",
        change_set_name=network_cs,
        description="Automated SEIS 615 two-AZ Cafe network deployment",
        parameter=[
            "EnvironmentName=cafe",
            "WorkstationIP=131.212.248.222/32",
            "BastionKeyPairName=cafe-key-pair"
        ],
        tags=["Project=SEIS615", "ManagedBy=CloudFormationAgent"],
        capability=None
    )

    print("\n\nSTAGE 1/4 — PLAN NETWORK")
    plan(network_args)
    execute(argparse.Namespace(stack="cafe-network", change_set=network_cs))
    net_status = aws_json([
        "cloudformation", "describe-stacks", "--stack-name", "cafe-network"
    ])
    net_state = net_status["Stacks"][0]["StackStatus"]
    if net_state != "CREATE_COMPLETE":
        raise SystemExit(f"Network stack did not complete successfully: {net_state}")

    # Stage 2: Application
    app_cs = "cafe-application-auto-" + dt.datetime.now().strftime("%Y%m%d%H%M%S")
    app_args = argparse.Namespace(
        stack="cafe-application",
        template="templates/lab-application.yaml",
        change_set_name=app_cs,
        description="Automated SEIS 615 Cafe application deployment",
        parameter=[
            "EnvironmentName=cafe",
            "ApplicationKeyPairName=cafe-key-pair",
            "ASGMinSize=2",
            "ASGDesiredCapacity=2",
            "ASGMaxSize=4",
            "DatabaseMultiAZ=true"
        ],
        tags=["Project=SEIS615", "ManagedBy=CloudFormationAgent"],
        capability=["CAPABILITY_IAM"]
    )

    print("\n\nSTAGE 2/4 — PLAN APPLICATION")
    plan(app_args)
    execute(argparse.Namespace(stack="cafe-application", change_set=app_cs))
    app_status = aws_json([
        "cloudformation", "describe-stacks", "--stack-name", "cafe-application"
    ])
    app_state = app_status["Stacks"][0]["StackStatus"]
    if app_state != "CREATE_COMPLETE":
        raise SystemExit(f"Application stack did not complete successfully: {app_state}")


    # Stage 3: Verify deployed infrastructure and application.
    import subprocess
    import time

    print("\n\nSTAGE 3/4 — VERIFY DEPLOYED RESOURCES")

    evidence = {
        "account": identity.get("Account", "unknown"),
        "region": CFG["region"],
        "network": aws_json([
            "cloudformation", "describe-stacks", "--stack-name", "cafe-network"
        ]),
        "application": aws_json([
            "cloudformation", "describe-stacks", "--stack-name", "cafe-application"
        ]),
        "network_resources": aws_json([
            "cloudformation", "list-stack-resources", "--stack-name", "cafe-network"
        ]),
        "application_resources": aws_json([
            "cloudformation", "list-stack-resources", "--stack-name", "cafe-application"
        ]),
        "checks": {},
        "verification_failures": []
    }

    failures = evidence["verification_failures"]
    resources = evidence["application_resources"].get(
        "StackResourceSummaries", []
    )

    def resource_ids(resource_type):
        return [
            r["PhysicalResourceId"] for r in resources
            if r.get("ResourceType") == resource_type
            and r.get("ResourceStatus") == "CREATE_COMPLETE"
        ]

    lb_arns = resource_ids("AWS::ElasticLoadBalancingV2::LoadBalancer")
    tg_arns = resource_ids("AWS::ElasticLoadBalancingV2::TargetGroup")
    asg_names = resource_ids("AWS::AutoScaling::AutoScalingGroup")
    db_ids = resource_ids("AWS::RDS::DBInstance")

    app_stack = evidence["application"]["Stacks"][0]
    outputs = {
        o["OutputKey"]: o["OutputValue"]
        for o in app_stack.get("Outputs", [])
    }

    print("\nApplication stack outputs:")
    for key, value in outputs.items():
        print(f" - {key}: {value}")

    # Wait for and inspect the load balancer.
    if lb_arns:
        run([
            "elbv2", "wait", "load-balancer-available",
            "--load-balancer-arns", lb_arns[0]
        ], check=False)
        lb = aws_json([
            "elbv2", "describe-load-balancers",
            "--load-balancer-arns", lb_arns[0]
        ], check=False)
        evidence["checks"]["load_balancer"] = lb
        lb_items = lb.get("LoadBalancers", [])
        if not lb_items or lb_items[0].get("State", {}).get("Code") != "active":
            failures.append("Load balancer is not active.")
    else:
        failures.append("No successfully created load balancer was found.")

    # Wait for at least one registered target to become healthy.
    if tg_arns:
        run([
            "elbv2", "wait", "target-in-service",
            "--target-group-arn", tg_arns[0]
        ], check=False)
        health = aws_json([
            "elbv2", "describe-target-health",
            "--target-group-arn", tg_arns[0]
        ], check=False)
        evidence["checks"]["target_health"] = health
        target_items = health.get("TargetHealthDescriptions", [])
        healthy = [
            t for t in target_items
            if t.get("TargetHealth", {}).get("State") == "healthy"
        ]
        evidence["checks"]["healthy_target_count"] = len(healthy)
        print(f"\nHealthy ALB targets: {len(healthy)}")
        if not healthy:
            failures.append("No healthy ALB targets were found.")
    else:
        failures.append("No successfully created target group was found.")

    # Verify Auto Scaling desired capacity and InService instances.
    if asg_names:
        asg_data = aws_json([
            "autoscaling", "describe-auto-scaling-groups",
            "--auto-scaling-group-names", asg_names[0]
        ], check=False)
        groups = asg_data.get("AutoScalingGroups", [])
        evidence["checks"]["auto_scaling"] = asg_data

        if groups:
            group = groups[0]
            desired = group.get("DesiredCapacity", 0)
            in_service = [
                i for i in group.get("Instances", [])
                if i.get("LifecycleState") == "InService"
                and i.get("HealthStatus") == "Healthy"
            ]
            evidence["checks"]["asg_desired_capacity"] = desired
            evidence["checks"]["asg_healthy_in_service_count"] = len(in_service)
            print(f"ASG healthy InService instances: {len(in_service)} / {desired}")
            if len(in_service) < desired:
                failures.append(
                    f"ASG has {len(in_service)} healthy InService instances; "
                    f"desired capacity is {desired}."
                )
        else:
            failures.append("Auto Scaling group was not returned by AWS.")
    else:
        failures.append("No successfully created Auto Scaling group was found.")

    # Verify RDS availability and Multi-AZ configuration.
    if db_ids:
        run([
            "rds", "wait", "db-instance-available",
            "--db-instance-identifier", db_ids[0]
        ], check=False)
        db_data = aws_json([
            "rds", "describe-db-instances",
            "--db-instance-identifier", db_ids[0]
        ], check=False)
        evidence["checks"]["database"] = db_data
        db_items = db_data.get("DBInstances", [])

        if db_items:
            db = db_items[0]
            evidence["checks"]["database_status"] = db.get("DBInstanceStatus")
            evidence["checks"]["database_multi_az"] = db.get("MultiAZ")
            print(
                "\nRDS status:", db.get("DBInstanceStatus"),
                "| Multi-AZ:", db.get("MultiAZ")
            )
            if db.get("DBInstanceStatus") != "available":
                failures.append("RDS database is not available.")
            if db.get("MultiAZ") is not True:
                failures.append("RDS Multi-AZ is not enabled.")
        else:
            failures.append("RDS database details were not returned.")
    else:
        failures.append("No successfully created RDS instance was found.")

    # Probe the Café application and record the actual HTTP status.
    app_url = next(
        (v for k, v in outputs.items() if "url" in k.lower()),
        None
    )
    if not app_url:
        dns = next(
            (v for k, v in outputs.items() if "dns" in k.lower()),
            None
        )
        if dns:
            app_url = "http://" + dns + "/cafe/"

    if app_url:
        if not app_url.startswith("http"):
            app_url = "http://" + app_url
        if not app_url.endswith("/"):
            app_url += "/"

        print("\nHTTP application probe:", app_url)
        try:
            probe = subprocess.run(
                [
                    "curl", "-sS", "-o", "/dev/null",
                    "-w", "%{http_code}", "--max-time", "30", app_url
                ],
                capture_output=True,
                text=True,
                timeout=35
            )
            http_status = probe.stdout.strip()
            evidence["checks"]["http_probe"] = {
                "url": app_url,
                "http_status": http_status,
                "returncode": probe.returncode,
                "stderr": probe.stderr.strip()
            }
            print("HTTP status:", http_status or "No response")
            if probe.returncode != 0 or http_status != "200":
                failures.append(
                    f"Application HTTP probe failed: status={http_status}, "
                    f"curl_returncode={probe.returncode}."
                )
        except Exception as exc:
            evidence["checks"]["http_probe"] = {
                "url": app_url,
                "error": str(exc)
            }
            failures.append(f"Application HTTP probe could not complete: {exc}")
    else:
        failures.append("No application URL or load balancer DNS output was found.")

    # Always save evidence, including failed verification results.
    evidence["verification_passed"] = not failures
    evidence["verification_failures"] = failures

    evidence_path = EVIDENCE_DIR / "automated-deployment-verification.json"
    evidence_path.write_text(json.dumps(evidence, indent=2, default=str))

    log_event("automated_deployment_and_verification_finished", {
        "network_status": net_state,
        "application_status": app_state,
        "verification_passed": not failures,
        "verification_failures": failures,
        "evidence": str(evidence_path)
    })

    print("\n\nSTAGE 4/4 — EVIDENCE SAVED")
    print("Evidence:", evidence_path)
    print("Network stack:", net_state)
    print("Application stack:", app_state)

    if failures:
        print("\nVERIFICATION FAILED:")
        for failure in failures:
            print(" -", failure)
        raise SystemExit(
            "\nInfrastructure deployment completed, but application "
            "verification failed. Resources remain deployed for inspection."
        )

    print("\nAll infrastructure and application checks passed.")
    print("AWS resources remain deployed until explicitly cleaned up.")


def main():
    global CFG
    CFG = load_config()
    parser = argparse.ArgumentParser(description="Human-approved CloudFormation assignment agent")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("run-all", help="Automated Cafe deployment and verification")

    sub.add_parser("doctor", help="Check AWS CLI, identity, account and configured region")
    sub.add_parser("inspect", help="Read-only inspection of stacks and exports")

    v = sub.add_parser("validate", help="Validate one template with CloudFormation")
    v.add_argument("template")

    p = sub.add_parser("plan", help="Create a CloudFormation change set; does not deploy")
    p.add_argument("--stack", required=True)
    p.add_argument("--template", required=True)
    p.add_argument("--change-set-name")
    p.add_argument("--description")
    p.add_argument("--parameter", action="append", default=[], help="ParameterKey=ParameterValue; repeatable")
    p.add_argument("--tag", dest="tags", action="append", default=[], help="Key=Value; repeatable")
    p.add_argument("--capability", action="append", choices=["CAPABILITY_IAM", "CAPABILITY_NAMED_IAM", "CAPABILITY_AUTO_EXPAND"])

    e = sub.add_parser("execute", help="Execute an existing, reviewed change set after exact approval")
    e.add_argument("--stack", required=True)
    e.add_argument("--change-set", required=True)

    s = sub.add_parser("status", help="Show stack status, outputs and resources")
    s.add_argument("--stack", required=True)

    cp = sub.add_parser("cleanup-plan", help="Show stack resources before cleanup; read-only")
    cp.add_argument("--stack", required=True)

    c = sub.add_parser("cleanup", help="Request stack deletion after explicit approval")
    c.add_argument("--stack", required=True)
    c.add_argument("--confirm", action="store_true")

    args = parser.parse_args()
    if args.command == "run-all":
        run_all(args)
    elif args.command == "doctor":
        ensure_environment()
        print("\nEnvironment check passed. No AWS resources were created or changed.")
    elif args.command == "inspect":
        inspect(args)
    elif args.command == "validate":
        ensure_environment()
        validate_template(args)
    elif args.command == "plan":
        plan(args)
    elif args.command == "execute":
        execute(args)
    elif args.command == "status":
        status(args)
    elif args.command == "cleanup-plan":
        cleanup_plan(args)
    elif args.command == "cleanup":
        cleanup(args)


if __name__ == "__main__":
    main()
